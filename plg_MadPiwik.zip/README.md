MadPiwik
========

A Joomla! plugin to include a Piwik tracking code on your Joomla! website. This plugin is compatible with Joomla! versions 1.5, 2.5 and 3.0.
